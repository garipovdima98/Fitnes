using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Фитнес
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            InstallExceptionHandlers();
            ConfigureDataDirectory();
            ConfigureWorkingTemp();

            // Диагностический режим: FITNES_SELFTEST=1 — проверяет доступ к базе и выходит.
            if (Environment.GetEnvironmentVariable("FITNES_SELFTEST") == "1")
            {
                RunSelfTest();
                return;
            }

            // 1. Форма входа. 2. Если вход успешен — главная панель.
            using (var loginForm = new Main())
            {
                Application.Run(loginForm);

                if (!loginForm.IsAuthenticated) return;

                Application.Run(new Form1(loginForm.UserRole, loginForm.UserClientId));
            }
        }

        /// <summary>
        /// Любая необработанная ошибка попадает в error.log с понятным текстом,
        /// а не в стандартное окно .NET с «Unhandled exception».
        /// </summary>
        private static void InstallExceptionHandlers()
        {
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);

            Application.ThreadException += (s, e) =>
            {
                AppLog.WriteException("необработанная ошибка интерфейса", e.Exception);

                MessageBox.Show(
                    "Произошла непредвиденная ошибка:" + Environment.NewLine + e.Exception.Message +
                    Environment.NewLine + Environment.NewLine + "Подробности записаны в error.log.",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            };

            AppDomain.CurrentDomain.UnhandledException += (s, e) =>
                AppLog.WriteException("необработанная ошибка", e.ExceptionObject as Exception);
        }

        /// <summary>Второе расположение базы (сейчас не используется, оставлено для совместимости).</summary>
        public static string AlternateDatabasePath { get; private set; }

        /// <summary>Что решили при старте — пишется в error.log при сбое (для диагностики).</summary>
        public static string StartupInfo { get; private set; }

        /// <summary>Папка временных файлов, которой пользуются приложение и драйвер Access.</summary>
        public static string TempFolder { get; private set; }

        /// <summary>
        /// Драйвер Access создаёт временные файлы в %TEMP%. Если процесс не может писать
        /// в системную папку временных файлов (например, запущен с пониженными правами),
        /// подключение к базе падает с «Неопознанной ошибкой». Поэтому временные файлы
        /// держим рядом с базой — в папке проекта.
        /// </summary>
        private static void ConfigureWorkingTemp()
        {
            try
            {
                string folder = Path.Combine(AppPaths.DataFolder, "temp");
                Directory.CreateDirectory(folder);

                // Проверяем, что писать туда действительно можно.
                string probe = Path.Combine(folder, "probe.tmp");
                File.WriteAllText(probe, "ok");
                File.Delete(probe);

                Environment.SetEnvironmentVariable("TMP", folder);
                Environment.SetEnvironmentVariable("TEMP", folder);
                TempFolder = folder;
            }
            catch (Exception ex)
            {
                TempFolder = Path.GetTempPath();
                AppLog.WriteException("папка временных файлов", ex);
            }
        }

        /// <summary>
        /// Всё хранится в папке проекта: база ищется рядом с exe и выше по дереву
        /// (bin\Debug → bin → корень проекта). Ничего вне папки проекта не создаётся,
        /// поэтому проект можно скопировать на другой ПК целиком и запустить.
        /// </summary>
        private static void ConfigureDataDirectory()
        {
            string projectDb = FindProjectDatabase();

            if (projectDb != null)
            {
                string folder = Path.GetDirectoryName(projectDb);
                AppDomain.CurrentDomain.SetData("DataDirectory", folder);
                MigrateSystemConfig(folder);
                StartupInfo = "база проекта: " + projectDb;
                return;
            }

            StartupInfo = "база не найдена рядом с exe и выше по дереву";
            // Не нашли — остаётся поведение по умолчанию (папка exe),
            // ошибка подключения будет видна с понятным сообщением.
        }

        /// <summary>Ищет базу в папке проекта (рядом с exe и выше по дереву).</summary>
        private static string FindProjectDatabase()
        {
            string dir = AppDomain.CurrentDomain.BaseDirectory;

            for (int level = 0; level < 6 && !string.IsNullOrEmpty(dir); level++)
            {
                string candidate = Path.Combine(dir, "фитнес.accdb");
                if (File.Exists(candidate)) return candidate;

                string parent = Path.GetDirectoryName(dir.TrimEnd(Path.DirectorySeparatorChar));
                if (string.IsNullOrEmpty(parent) || parent == dir) break;
                dir = parent;
            }

            return null;
        }

        /// <summary>
        /// Переносит логины/пароли клиентов (system_config.dat) в папку с базой,
        /// если там такого файла ещё нет: ищем его рядом с exe и в папках проекта.
        /// </summary>
        private static void MigrateSystemConfig(string dataFolder)
        {
            try
            {
                string target = Path.Combine(dataFolder, "system_config.dat");
                if (File.Exists(target)) return;

                foreach (var candidate in SystemConfigCandidates())
                {
                    if (!File.Exists(candidate)) continue;
                    if (new FileInfo(candidate).Length == 0) continue;

                    Directory.CreateDirectory(dataFolder);

                    // перезаписываем без BOM, чтобы логин в первой строке читался корректно
                    string text = File.ReadAllText(candidate, Encoding.UTF8);
                    if (!text.EndsWith("\n", StringComparison.Ordinal)) text += Environment.NewLine;

                    File.WriteAllText(target, text, new UTF8Encoding(false));
                    File.SetAttributes(target, FileAttributes.Hidden);
                    return;
                }
            }
            catch { /* миграция не должна мешать запуску */ }
        }

        private static IEnumerable<string> SystemConfigCandidates()
        {
            string dir = AppDomain.CurrentDomain.BaseDirectory;

            for (int level = 0; level < 6 && !string.IsNullOrEmpty(dir); level++)
            {
                yield return Path.Combine(dir, "system_config.dat");

                string parent = Path.GetDirectoryName(dir.TrimEnd(Path.DirectorySeparatorChar));
                if (string.IsNullOrEmpty(parent) || parent == dir) break;
                dir = parent;
            }
        }

        /// <summary>
        /// Диагностика доступа к базе: пишет отчёт в selftest.log рядом с exe.
        /// Запуск: set FITNES_SELFTEST=1 &amp;&amp; Фитнес.exe
        /// </summary>
        private static void RunSelfTest()
        {
            var sb = new StringBuilder();
            Action<string> w = s => sb.AppendLine(s);

            w("время: " + DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss"));
            w("процесс: " + (Environment.Is64BitProcess ? "64-bit" : "32-bit"));
            w("BaseDirectory: " + AppDomain.CurrentDomain.BaseDirectory);
            w("DataDirectory: " + Convert.ToString(AppDomain.CurrentDomain.GetData("DataDirectory")));
            w("токен пользователя: " + Environment.UserName);
            w("exe: " + System.Reflection.Assembly.GetExecutingAssembly().Location);

            try
            {
                w("ConnStr: " + DbHelper.ConnectionString);

                string path = DbHelper.DatabasePath;
                w("файл базы: " + path);
                w("файл существует: " + File.Exists(path));

                try
                {
                    using (var fs = File.Open(path, FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite))
                        w("прямое открытие файла: OK (" + fs.Length + " байт)");
                }
                catch (Exception ex) { w("прямое открытие файла: FAIL " + ex.GetType().Name + ": " + ex.Message); }

                int clients = DbHelper.Count("SELECT COUNT(*) FROM [Клиенты]");
                w("запрос к базе: OK, клиентов = " + clients);
            }
            catch (Exception ex)
            {
                w("СБОЙ: " + ex);
                w("описание: " + DbHelper.Describe(ex));
            }

            try
            {
                string logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "selftest.log");
                File.AppendAllText(logPath, sb.ToString() + Environment.NewLine, Encoding.UTF8);
            }
            catch { }

            Environment.Exit(0);
        }
    }

    /// <summary>
    /// Общий журнал ошибок: пишет рядом с exe в error.log.
    /// </summary>
    internal static class AppLog
    {
        private static readonly object Sync = new object();

        public static string FilePath
        {
            get { return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "error.log"); }
        }

        public static void Write(string title, string text)
        {
            try
            {
                lock (Sync)
                {
                    File.AppendAllText(
                        FilePath,
                        string.Format("[{0:dd.MM.yyyy HH:mm:ss}] {1}{2}{3}{2}{2}",
                            DateTime.Now, title, Environment.NewLine, text),
                        Encoding.UTF8);
                }
            }
            catch { /* журнал не должен мешать работе программы */ }
        }

        public static void WriteException(string title, Exception ex)
        {
            if (ex == null) { Write(title, "исключение без описания"); return; }

            string connection = string.Empty;
            try { connection = Environment.NewLine + "ConnStr: " + DbHelper.ConnectionString; }
            catch { /* строку подключения получить не удалось — не мешает записи журнала */ }

            Write(title, ex + connection);
        }
    }

    /// <summary>
    /// Пути к файлам данных приложения. Всё лежит в одной папке — там, где база,
    /// чтобы пересборка и удаление bin не теряли данные.
    /// </summary>
    internal static class AppPaths
    {
        public static string DataFolder
        {
            get
            {
                string dir = AppDomain.CurrentDomain.GetData("DataDirectory") as string;
                return string.IsNullOrEmpty(dir) ? AppDomain.CurrentDomain.BaseDirectory : dir;
            }
        }

        /// <summary>Файл с логинами/паролями клиентов (login|password|id_клиента).</summary>
        public static string SystemConfig
        {
            get { return Path.Combine(DataFolder, "system_config.dat"); }
        }

        /// <summary>Строки файла учётных записей (пустой массив, если файла нет или он недоступен).</summary>
        public static string[] ReadUserLines()
        {
            try
            {
                if (!File.Exists(SystemConfig)) return new string[0];
                return File.ReadAllLines(SystemConfig);
            }
            catch (Exception ex)
            {
                AppLog.WriteException("чтение " + Path.GetFileName(SystemConfig), ex);
                return new string[0];
            }
        }

        /// <summary>Занят ли логин (без учёта регистра).</summary>
        public static bool IsLoginTaken(string login)
        {
            string value = (login ?? string.Empty).Trim();
            if (value.Length == 0) return false;

            foreach (string line in ReadUserLines())
            {
                string[] parts = line.Split('|');
                if (parts.Length >= 1 && string.Equals(parts[0].Trim(), value, StringComparison.OrdinalIgnoreCase))
                    return true;
            }

            return false;
        }

        /// <summary>Проверяет логин/пароль и возвращает id клиента из файла учётных записей.</summary>
        public static bool TryFindUser(string login, string password, out int? clientId)
        {
            clientId = null;

            foreach (string line in ReadUserLines())
            {
                string[] parts = line.Split('|');
                if (parts.Length < 2) continue;
                if (!string.Equals(parts[0].Trim(), login, StringComparison.OrdinalIgnoreCase)) continue;
                if (!string.Equals(parts[1], password, StringComparison.Ordinal)) continue;

                int id;
                if (parts.Length >= 3 && int.TryParse(parts[2].Trim(), out id) && id > 0)
                    clientId = id;

                return true;
            }

            return false;
        }

        /// <summary>
        /// Добавляет учётную запись. Если в файле нет перевода строки в конце,
        /// он добавляется — иначе новая запись склеится с предыдущей.
        /// </summary>
        public static void AppendUser(string login, string password, int clientId)
        {
            string path = SystemConfig;
            bool exists = File.Exists(path);
            FileAttributes attributes = exists ? File.GetAttributes(path) : FileAttributes.Hidden;

            string text = login + "|" + password + "|" + clientId + Environment.NewLine;

            if (exists)
            {
                string current = File.ReadAllText(path);
                if (current.Length > 0 && !current.EndsWith("\n", StringComparison.Ordinal))
                    text = Environment.NewLine + text;

                File.SetAttributes(path, FileAttributes.Normal);
            }

            try
            {
                File.AppendAllText(path, text, new UTF8Encoding(false));
            }
            finally
            {
                if (File.Exists(path))
                    File.SetAttributes(path, attributes | FileAttributes.Hidden);
            }
        }
    }
}
