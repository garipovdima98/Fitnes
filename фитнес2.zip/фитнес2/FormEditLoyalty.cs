using System;
using System.Data;
using System.Windows.Forms;

namespace Фитнес
{
    public partial class FormEditLoyalty : Form
    {
        private readonly int _cardId;

        public FormEditLoyalty(int cardId)
        {
            InitializeComponent();
            _cardId = cardId;
        }

        private void FormEditLoyalty_Load(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = DbHelper.Query("SELECT * FROM [Карта лояльности] WHERE [id_карты] = ?", _cardId);

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("Карта лояльности не найдена в базе.", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    btnSave.Enabled = false;
                    return;
                }

                DataRow row = dt.Rows[0];

                txtCardNum.Text = LoyaltyHelper.NormalizeNumber(Convert.ToString(row["номер карты"]));
                txtPoints.Text = row["баллов"] == DBNull.Value ? "0" : row["баллов"].ToString();
                txtDiscount.Text = row["скидка"] == DBNull.Value ? "0" : row["скидка"].ToString();
            }
            catch (Exception ex)
            {
                AppLog.WriteException("загрузка карты лояльности", ex);
                MessageBox.Show("Ошибка загрузки карты: " + DbHelper.Describe(ex), "Ошибка БД",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnSave.Enabled = false;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string number = LoyaltyHelper.NormalizeNumber(txtCardNum.Text);

            if (number.Length == 0)
            {
                MessageBox.Show("Введите номер карты.");
                return;
            }

            if (number.IndexOf('|') >= 0)
            {
                MessageBox.Show("Символ «|» в номере карты недопустим.");
                return;
            }

            int points;
            if (!int.TryParse(txtPoints.Text.Trim(), out points) || points < 0)
            {
                MessageBox.Show("Баллы должны быть целым неотрицательным числом.");
                return;
            }

            int discount;
            if (!int.TryParse(txtDiscount.Text.Trim(), out discount) || discount < 0 || discount > 100)
            {
                MessageBox.Show("Скидка должна быть целым числом от 0 до 100.");
                return;
            }

            string finalCardNum = LoyaltyHelper.Prefix + number;

            try
            {
                // Номер карты должен оставаться уникальным (сравнение без учёта текущей карты).
                if (DbHelper.Count(
                        "SELECT COUNT(*) FROM [Карта лояльности] WHERE [номер карты] = ? AND [id_карты] <> ?",
                        finalCardNum, _cardId) > 0)
                {
                    MessageBox.Show("Карта с таким номером уже существует.");
                    return;
                }

                DbHelper.Execute(
                    "UPDATE [Карта лояльности] SET [номер карты] = ?, [баллов] = ?, [скидка] = ? WHERE [id_карты] = ?",
                    finalCardNum, points, discount, _cardId);

                MessageBox.Show("Карта обновлена!");
                this.Close();
            }
            catch (Exception ex)
            {
                AppLog.WriteException("сохранение карты лояльности", ex);
                MessageBox.Show(
                    "Ошибка сохранения: " + DbHelper.Describe(ex) + Environment.NewLine +
                    "Подробности записаны в error.log рядом с exe.",
                    "Ошибка БД", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e) => this.Close();
    }
}
