using System;
using System.Data;
using System.Windows.Forms;

namespace Фитнес
{
    public partial class FormAddSub : Form
    {
        private int? lockedClientId = null;

        // Конструктор для Администратора
        public FormAddSub()
        {
            InitializeComponent();
            SetupForm();
        }

        // Конструктор для Клиента (ID фиксирован)
        public FormAddSub(int clientId) : this()
        {
            lockedClientId = clientId;
        }

        private void SetupForm()
        {
            dtpStart.Value = DateTime.Today;
            cmbType.SelectedIndexChanged += (s, e) => UpdateEndDate();
            dtpStart.ValueChanged += (s, e) => UpdateEndDate();

            // Тип абонемента выбирается из списка (поле не редактируется вручную).
            if (cmbType.Items.Count > 0) cmbType.SelectedIndex = 0;

            UpdateEndDate();
        }

        /// <summary>Дата окончания: годовой абонемент — 12 месяцев, остальные — 1 месяц.</summary>
        private static DateTime GetEndDate(DateTime start, string subscriptionType)
        {
            if (string.IsNullOrEmpty(subscriptionType)) return start;

            return subscriptionType.StartsWith("Годовой", StringComparison.OrdinalIgnoreCase)
                ? start.AddYears(1)
                : start.AddMonths(1);
        }

        private static string GetStatus(DateTime endDate)
        {
            return endDate.Date >= DateTime.Today ? "активно" : "неактивен";
        }

        private void FormAddSub_Load(object sender, EventArgs e)
        {
            try
            {
                LoadComboClients();
            }
            catch (Exception ex)
            {
                AppLog.WriteException("список клиентов для абонемента", ex);
                MessageBox.Show(
                    "Не удалось загрузить список клиентов: " + DbHelper.Describe(ex),
                    "Ошибка БД", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnSave.Enabled = false;
                return;
            }

            // Если вошёл клиент — фиксируем его
            if (lockedClientId.HasValue)
            {
                bool found = SelectClient(lockedClientId.Value);
                cmbClient.Enabled = false;
                cmbClient.BackColor = System.Drawing.Color.LightGray;

                if (!found)
                {
                    MessageBox.Show(
                        "Клиент, к которому привязана учётная запись, не найден в базе.\n" +
                        "Оформление абонемента недоступно.",
                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    btnSave.Enabled = false;
                }
            }
        }

        private bool SelectClient(int clientId)
        {
            for (int i = 0; i < cmbClient.Items.Count; i++)
            {
                DataRowView row = cmbClient.Items[i] as DataRowView;
                if (row != null && Convert.ToInt32(row["id_клиента"]) == clientId)
                {
                    cmbClient.SelectedIndex = i;
                    return true;
                }
            }

            return false;
        }

        private void LoadComboClients()
        {
            // ФИО собираем в C#: пустое отчество и лишние пробелы в базе не портят список.
            var dt = DbHelper.Query(
                "SELECT id_клиента, фамилия, имя, отчество FROM [Клиенты] ORDER BY фамилия, имя");

            PersonName.AddFullNameColumn(dt, "ФИО", "фамилия", "имя", "отчество");

            cmbClient.DataSource = dt;
            cmbClient.DisplayMember = "ФИО";
            cmbClient.ValueMember = "id_клиента";
        }

        private void UpdateEndDate()
        {
            if (string.IsNullOrEmpty(cmbType.Text)) return;

            var start = dtpStart.Value.Date;
            var end = GetEndDate(start, cmbType.Text);
            var status = GetStatus(end);

            lblEndDate.Text = $"{end:dd.MM.yyyy} ({status})";
            lblEndDate.ForeColor = status == "активно" ? System.Drawing.Color.Green : System.Drawing.Color.Red;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // 1. Определяем ID клиента
            int clientId;
            if (lockedClientId.HasValue && lockedClientId.Value > 0)
            {
                clientId = lockedClientId.Value;
            }
            else
            {
                if (cmbClient.SelectedValue == null)
                {
                    MessageBox.Show("Выберите клиента из списка.");
                    return;
                }
                clientId = Convert.ToInt32(cmbClient.SelectedValue);
            }

            if (clientId <= 0)
            {
                MessageBox.Show("Не удалось определить клиента. Выберите его из списка.");
                return;
            }

            string subscriptionType = cmbType.Text;
            if (string.IsNullOrEmpty(subscriptionType))
            {
                MessageBox.Show("Выберите тип абонемента.");
                return;
            }

            var start = dtpStart.Value.Date;
            var end = GetEndDate(start, subscriptionType);
            var status = GetStatus(end);

            try
            {
                if (DbHelper.Count("SELECT COUNT(*) FROM [Клиенты] WHERE [id_клиента] = ?", clientId) == 0)
                {
                    MessageBox.Show("Клиент не найден в базе. Обновите список и попробуйте снова.");
                    return;
                }

                // 2. Проверка на дубликат
                if (DbHelper.Count(
                        "SELECT COUNT(*) FROM [Абонементы] WHERE [id_клинета]=? AND [тип_абонемента]=? AND [статус]='активно'",
                        clientId, subscriptionType) > 0)
                {
                    MessageBox.Show("У этого клиента уже есть активный абонемент такого типа.");
                    return;
                }

                DbHelper.Execute(
                    "INSERT INTO [Абонементы] ([id_клинета], [тип_абонемента], [начало], [конец], [статус]) VALUES (?, ?, ?, ?, ?)",
                    clientId, subscriptionType, start, end, status);

                MessageBox.Show("Абонемент успешно оформлен!");
                this.Close();
            }
            catch (Exception ex)
            {
                AppLog.WriteException("оформление абонемента", ex);
                MessageBox.Show(
                    "Ошибка при оформлении: " + DbHelper.Describe(ex) + Environment.NewLine +
                    "Подробности записаны в error.log рядом с exe.",
                    "Ошибка БД", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
