using System;

namespace Фитнес
{
    /// <summary>
    /// Работа с картами лояльности: создание карты и проверка номера.
    /// Номер генерируется в одном месте, чтобы не было дублей и «CARD-CARD-...».
    /// </summary>
    public static class LoyaltyHelper
    {
        public const string Prefix = "CARD-";

        /// <summary>Создаёт новую карту лояльности и возвращает её id.</summary>
        public static int CreateCard()
        {
            for (int attempt = 0; attempt < 5; attempt++)
            {
                string number = Prefix + DateTime.Now.ToString("yyMMddHHmmssff");

                // На всякий случай проверяем уникальность: две карты с одним номером недопустимы.
                if (DbHelper.Count("SELECT COUNT(*) FROM [Карта лояльности] WHERE [номер карты] = ?", number) > 0)
                    continue;

                DbHelper.Execute(
                    "INSERT INTO [Карта лояльности] ([номер карты], [баллов], [скидка]) VALUES (?, 0, 0)",
                    number);

                int id = DbHelper.ScalarInt("SELECT MAX(id_карты) FROM [Карта лояльности]");
                if (id > 0) return id;
            }

            throw new InvalidOperationException("Не удалось создать карту лояльности (номер не освободился).");
        }

        /// <summary>Полный номер карты по тому, что ввёл пользователь (без префикса и с ним).</summary>
        public static string NormalizeNumber(string number)
        {
            string value = (number ?? string.Empty).Trim();

            // Пользователь мог ввести номер вместе с префиксом — второй раз его не добавляем.
            while (value.StartsWith(Prefix, StringComparison.OrdinalIgnoreCase))
                value = value.Substring(Prefix.Length).Trim();

            return value;
        }
    }
}
