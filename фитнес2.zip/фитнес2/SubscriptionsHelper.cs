using System;

namespace Фитнес
{
    public static class SubscriptionsHelper
    {
        /// <summary>
        /// Приводит статусы абонементов в соответствие с датой окончания.
        /// Ошибку не «проглатываем» — она попадает в error.log.
        /// </summary>
        public static void ОбновитьСтатусы()
        {
            try
            {
                var today = DateTime.Today;
                DbHelper.Execute("UPDATE [Абонементы] SET [статус] = 'неактивен' WHERE [конец] < ? OR [конец] IS NULL", today);
                DbHelper.Execute("UPDATE [Абонементы] SET [статус] = 'активно' WHERE [конец] >= ?", today);
            }
            catch (Exception ex)
            {
                AppLog.WriteException("обновление статусов абонементов", ex);
            }
        }
    }
}
