using System;
using System.Windows.Forms;

namespace Фитнес
{
    public partial class FormAddClient : Form
    {
        public FormAddClient() { InitializeComponent(); }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string lastName = txtLast.Text.Trim();
            string firstName = txtFirst.Text.Trim();
            string middleName = txtMiddle.Text.Trim();
            string phone = PhoneHelper.Normalize(txtPhone.Text);

            if (lastName.Length == 0 || firstName.Length == 0)
            {
                MessageBox.Show("Введите фамилию и имя.");
                return;
            }

            if (string.IsNullOrEmpty(phone))
            {
                MessageBox.Show("Телефон должен содержать 10 или 11 цифр, например +7 999 123-45-67.");
                return;
            }

            // Все обращения к базе — внутри try: иначе ошибка БД «уронит» форму.
            try
            {
                if (DbHelper.Count("SELECT COUNT(*) FROM [Клиенты] WHERE [телефон] = ?", phone) > 0)
                {
                    MessageBox.Show("Клиент с таким телефоном уже есть.");
                    return;
                }

                int cardId = LoyaltyHelper.CreateCard();

                DbHelper.Execute(
                    "INSERT INTO [Клиенты] ([фамилия],[имя],[отчество],[телефон],[id_карты]) VALUES (?, ?, ?, ?, ?)",
                    lastName, firstName, middleName, phone, cardId);

                MessageBox.Show("Клиент добавлен!");
                this.Close();
            }
            catch (Exception ex)
            {
                AppLog.WriteException("добавление клиента", ex);
                MessageBox.Show(
                    "Не удалось добавить клиента: " + DbHelper.Describe(ex) + Environment.NewLine +
                    "Подробности записаны в error.log рядом с exe.",
                    "Ошибка БД", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e) => this.Close();
    }
}
