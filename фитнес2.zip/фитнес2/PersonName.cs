using System;
using System.Collections.Generic;
using System.Data;

namespace Фитнес
{
    /// <summary>
    /// Отображение ФИО в таблицах и списках.
    /// В таблицах используется короткая форма «Соколов Р.И.», в списках выбора — полная.
    /// Лишние пробелы (например, «Васильева  Ангелина») убираются.
    /// </summary>
    public static class PersonName
    {
        /// <summary>Короткое ФИО: «Соколов Р.И.».</summary>
        public static string Short(string lastName, string firstName, string middleName)
        {
            string last = Trim(lastName);
            string initials = Initial(firstName) + Initial(middleName);

            if (initials.Length == 0) return last;
            if (last.Length == 0) return initials;

            return last + " " + initials;
        }

        /// <summary>Полное ФИО: «Соколов Роман Игоревич».</summary>
        public static string Full(string lastName, string firstName, string middleName)
        {
            return Join(Trim(lastName), Trim(firstName), Trim(middleName));
        }

        /// <summary>
        /// Добавляет в таблицу вычисляемую колонку с ФИО.
        /// Если исходных колонок нет, ничего не делает — вызывающий код не падает.
        /// </summary>
        public static void AddNameColumn(DataTable table, string columnName,
            string lastNameColumn, string firstNameColumn, string middleNameColumn,
            bool shortForm, int ordinal)
        {
            if (table == null || table.Columns.Contains(columnName)) return;
            if (!table.Columns.Contains(lastNameColumn)) return;
            if (!table.Columns.Contains(firstNameColumn)) return;
            if (!table.Columns.Contains(middleNameColumn)) return;

            table.Columns.Add(columnName, typeof(string));

            foreach (DataRow row in table.Rows)
            {
                string last = Text(row[lastNameColumn]);
                string first = Text(row[firstNameColumn]);
                string middle = Text(row[middleNameColumn]);

                row[columnName] = shortForm ? Short(last, first, middle) : Full(last, first, middle);
            }

            // Ставим колонку с ФИО туда, где её ждёт пользователь, а не в конец таблицы.
            if (ordinal >= 0 && ordinal < table.Columns.Count)
                table.Columns[columnName].SetOrdinal(ordinal);
        }

        /// <summary>Добавляет полное ФИО (для выпадающих списков).</summary>
        public static void AddFullNameColumn(DataTable table, string columnName,
            string lastNameColumn, string firstNameColumn, string middleNameColumn)
        {
            AddNameColumn(table, columnName, lastNameColumn, firstNameColumn, middleNameColumn, false, -1);
        }

        private static string Join(string lastName, string firstName, string middleName)
        {
            var parts = new List<string>(3);

            if (!string.IsNullOrEmpty(lastName)) parts.Add(lastName);
            if (!string.IsNullOrEmpty(firstName)) parts.Add(firstName);
            if (!string.IsNullOrEmpty(middleName)) parts.Add(middleName);

            return string.Join(" ", parts.ToArray());
        }

        private static string Initial(string value)
        {
            string text = Trim(value);
            if (text.Length == 0) return string.Empty;

            return text.Substring(0, 1).ToUpperInvariant() + ".";
        }

        private static string Trim(string value)
        {
            return (value ?? string.Empty).Trim();
        }

        private static string Text(object value)
        {
            if (value == null || value == DBNull.Value) return string.Empty;
            return Convert.ToString(value).Trim();
        }
    }
}
