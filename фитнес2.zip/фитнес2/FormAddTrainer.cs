using System;
using System.Windows.Forms;

namespace Фитнес
{
    public partial class FormAddTrainer : Form
    {
        public FormAddTrainer()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string lastName = txtLast.Text.Trim();
            string firstName = txtFirst.Text.Trim();
            string middleName = txtMiddle.Text.Trim();
            string specialization = txtSpec.Text.Trim();

            if (lastName.Length == 0)
            {
                MessageBox.Show("Введите фамилию.");
                return;
            }

            try
            {
                if (DbHelper.Count(
                        "SELECT COUNT(*) FROM [Тренеры] WHERE [фамилия]=? AND [имя]=? AND [отчество]=?",
                        lastName, firstName, middleName) > 0)
                {
                    MessageBox.Show("Такой тренер уже есть.");
                    return;
                }

                DbHelper.Execute(
                    "INSERT INTO [Тренеры] ([фамилия],[имя],[отчество],[специальность]) VALUES (?, ?, ?, ?)",
                    lastName, firstName, middleName, specialization);

                MessageBox.Show("Тренер добавлен!");
                this.Close();
            }
            catch (Exception ex)
            {
                AppLog.WriteException("добавление тренера", ex);
                MessageBox.Show(
                    "Не удалось добавить тренера: " + DbHelper.Describe(ex) + Environment.NewLine +
                    "Подробности записаны в error.log рядом с exe.",
                    "Ошибка БД", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e) => this.Close();
    }
}
