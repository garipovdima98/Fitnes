using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.Odbc;
using System.Data.OleDb;
using System.IO;
using System.Security.Principal;
using System.Text;

namespace Фитнес
{
    public static class DbHelper
    {
        private static readonly string ConnStr = BuildConnStr();

        // Сработавший способ подключения запоминается на весь процесс.
        private static Func<DbConnection> factory;
        private static string factoryName;

        // Резервный вариант «только чтение» — на случай, когда база занята другой программой.
        private static Func<DbConnection> readOnlyFactory;
        private static string readOnlyName;

        /// <summary>Строка подключения, уже с абсолютным путём к базе (для диагностики).</summary>
        public static string ConnectionString { get { return ConnStr; } }

        /// <summary>Сработавший способ подключения (null — ещё не подключались).</summary>
        public static string EffectiveConnectionString
        {
            get { return factoryName ?? readOnlyName; }
        }

        /// <summary>Путь к файлу базы, извлечённый из строки подключения.</summary>
        public static string DatabasePath
        {
            get
            {
                string cs = ConnStr ?? "";
                int i = cs.IndexOf("Data Source=", StringComparison.OrdinalIgnoreCase);
                if (i < 0) return "";
                return cs.Substring(i + "Data Source=".Length).Split(';')[0].Trim();
            }
        }

        /// <summary>
        /// Подставляет путь к базе вместо |DataDirectory| ещё до обращения к провайдеру:
        /// так строка подключения не зависит от того, когда именно .NET раскрывает макрос.
        /// </summary>
        private static string BuildConnStr()
        {
            ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings["FitnessDB"];

            if (settings != null && !string.IsNullOrWhiteSpace(settings.ConnectionString))
            {
                string configured = settings.ConnectionString;

                if (configured.IndexOf("|DataDirectory|", StringComparison.OrdinalIgnoreCase) >= 0)
                    configured = configured.Replace("|DataDirectory|", AppPaths.DataFolder);

                return configured;
            }

            // Страховка: exe.config мог не оказаться рядом с exe (запуск из другой папки,
            // копирование только exe). Тогда берём базу из папки данных.
            string fallback = Path.Combine(AppPaths.DataFolder, "фитнес.accdb");

            if (File.Exists(fallback))
                return "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + fallback;

            throw new InvalidOperationException(
                "В App.config нет строки подключения \"FitnessDB\", а файл фитнес.accdb не найден.");
        }

        // ---------------------------------------------------------------- запросы

        public static DataTable Query(string sql, params object[] parameters)
        {
            using (var conn = OpenConnection(false))
            using (var cmd = CreateCommand(conn, sql, parameters))
            using (var reader = cmd.ExecuteReader())
            {
                var dt = new DataTable();
                dt.Load(reader);
                return dt;
            }
        }

        /// <summary>
        /// INSERT/UPDATE/DELETE. Соединение «только чтение» здесь не используется:
        /// иначе запись падает с невнятной ошибкой «Multiple-step OLE DB operation generated errors».
        /// </summary>
        public static int Execute(string sql, params object[] parameters)
        {
            using (var conn = OpenConnection(true))
            using (var cmd = CreateCommand(conn, sql, parameters))
            {
                return cmd.ExecuteNonQuery();
            }
        }

        public static object Scalar(string sql, params object[] parameters)
        {
            using (var conn = OpenConnection(false))
            using (var cmd = CreateCommand(conn, sql, parameters))
            {
                return cmd.ExecuteScalar();
            }
        }

        /// <summary>
        /// COUNT(*) и подобные запросы: NULL/DBNull превращается в 0,
        /// чтобы не падать на Convert.ToInt32(DBNull.Value).
        /// </summary>
        public static int Count(string sql, params object[] parameters)
        {
            return ToInt(Scalar(sql, parameters));
        }

        /// <summary>Целое значение (например, MAX(id_карты)); NULL/DBNull — это 0.</summary>
        public static int ScalarInt(string sql, params object[] parameters)
        {
            return ToInt(Scalar(sql, parameters));
        }

        private static int ToInt(object value)
        {
            if (value == null || value == DBNull.Value) return 0;

            try { return Convert.ToInt32(value); }
            catch (Exception) { return 0; }
        }

        private static DbCommand CreateCommand(DbConnection conn, string sql, object[] parameters)
        {
            var cmd = conn.CreateCommand();
            cmd.CommandText = sql;

            if (parameters != null)
            {
                foreach (var value in parameters)
                {
                    var p = cmd.CreateParameter();
                    p.Value = value ?? DBNull.Value;
                    cmd.Parameters.Add(p);
                }
            }

            return cmd;
        }

        // ---------------------------------------------------------- подключение

        /// <summary>Один из вариантов подключения к базе.</summary>
        private sealed class ConnectionCandidate
        {
            public Func<DbConnection> Create;
            public string Label;
            public bool ReadOnly;
        }

        /// <summary>
        /// Открывает соединение: OLE DB (ACE 12.0 / 16.0), а если провайдер в этом процессе
        /// не инициализируется — через ODBC-драйвер Access. Вариант «только чтение»
        /// используется лишь для чтения: иначе запись падала бы с невнятной ошибкой OLE DB.
        /// Сработавший вариант запоминается.
        /// </summary>
        private static DbConnection OpenConnection(bool forWrite)
        {
            // Уже знаем рабочий вариант — пробуем его первым.
            if (factory != null)
            {
                var known = factory();
                try
                {
                    known.Open();
                    return known;
                }
                catch
                {
                    // База могла снова стать занятой — ищем вариант заново.
                    known.Dispose();
                    factory = null;
                    factoryName = null;
                }
            }

            if (!forWrite && readOnlyFactory != null)
            {
                var readOnly = readOnlyFactory();
                try
                {
                    readOnly.Open();
                    return readOnly;
                }
                catch
                {
                    readOnly.Dispose();
                    readOnlyFactory = null;
                    readOnlyName = null;
                }
            }

            Exception firstError = null;

            foreach (var candidate in Candidates(forWrite))
            {
                DbConnection conn = null;
                try
                {
                    conn = candidate.Create();
                    conn.Open();

                    if (candidate.ReadOnly)
                    {
                        readOnlyFactory = candidate.Create;
                        readOnlyName = candidate.Label;
                    }
                    else
                    {
                        factory = candidate.Create;
                        factoryName = candidate.Label;
                    }

                    return conn;
                }
                catch (Exception ex)
                {
                    if (firstError == null) firstError = ex;
                    if (conn != null) conn.Dispose();
                }
            }

            if (forWrite && !string.IsNullOrEmpty(readOnlyName))
            {
                throw new InvalidOperationException(
                    "База фитнес.accdb сейчас открыта только для чтения (" + readOnlyName + "), " +
                    "поэтому сохранить изменения нельзя. Закройте Access и другие копии программы и повторите.");
            }

            throw firstError ?? new InvalidOperationException("Не удалось подключиться к базе данных.");
        }

        private static bool ForceOdbc
        {
            get { return string.Equals(Environment.GetEnvironmentVariable("FITNES_DB_MODE"), "odbc", StringComparison.OrdinalIgnoreCase); }
        }

        private static List<ConnectionCandidate> Candidates(bool forWrite)
        {
            var list = new List<ConnectionCandidate>();

            foreach (var path in DatabasePaths())
            {
                // Запасной путь к базе подставляем в строку подключения,
                // только если основной путь вообще удалось выделить.
                string baseConnStr = ConnStr;
                string suffix = string.Empty;

                if (!string.IsNullOrEmpty(DatabasePath) &&
                    !string.Equals(path, DatabasePath, StringComparison.OrdinalIgnoreCase))
                {
                    baseConnStr = ConnStr.Replace(DatabasePath, path);
                    suffix = " [" + path + "]";
                }

                if (!ForceOdbc)
                {
                    string alt = baseConnStr.Replace("ACE.OLEDB.12.0", "ACE.OLEDB.16.0");

                    list.Add(new ConnectionCandidate
                    {
                        Create = () => new OleDbConnection(baseConnStr),
                        Label = "OLE DB ACE 12.0" + suffix
                    });

                    list.Add(new ConnectionCandidate
                    {
                        Create = () => new OleDbConnection(alt),
                        Label = "OLE DB ACE 16.0" + suffix
                    });

                    // Соединение только на чтение — резерв, когда база занята другой программой.
                    if (!forWrite)
                    {
                        list.Add(new ConnectionCandidate
                        {
                            Create = () => new OleDbConnection(baseConnStr + ";Mode=Read"),
                            Label = "OLE DB ACE 12.0 только чтение" + suffix,
                            ReadOnly = true
                        });
                    }
                }

                list.Add(new ConnectionCandidate
                {
                    Create = () => new OdbcConnection("Driver={Microsoft Access Driver (*.mdb, *.accdb)};Dbq=" + path + ";"),
                    Label = "ODBC Access" + suffix
                });
            }

            return list;
        }

        /// <summary>Все известные расположения файла базы: основное и запасное.</summary>
        private static IEnumerable<string> DatabasePaths()
        {
            string primary = DatabasePath;
            if (!string.IsNullOrEmpty(primary)) yield return primary;

            string alternate = Program.AlternateDatabasePath;
            if (!string.IsNullOrEmpty(alternate) &&
                !string.Equals(alternate, primary, StringComparison.OrdinalIgnoreCase) &&
                File.Exists(alternate))
            {
                yield return alternate;
            }
        }

        // ---------------------------------------------------------- диагностика

        /// <summary>
        /// Подробный отчёт о том, почему база не открывается: права, сам файл, провайдеры.
        /// Вызывается только при сбое загрузки — результат пишется в error.log.
        /// </summary>
        public static string Diagnose()
        {
            var sb = new StringBuilder();

            try
            {
                sb.AppendLine("--- диагностика базы " + DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss") + " ---");
                sb.AppendLine("процесс: " + (Environment.Is64BitProcess ? "64-bit" : "32-bit"));
                sb.AppendLine("пользователь: " + Environment.UserName);
                sb.AppendLine("повышенные права: " + IsElevated());
                sb.AppendLine("ConnStr: " + ConnStr);
                sb.AppendLine("сработавший вариант: " + (EffectiveConnectionString ?? "ещё не подключались"));
                sb.AppendLine("старт: " + Program.StartupInfo);

                string path = DatabasePath;
                sb.AppendLine("файл базы: " + path);
                sb.AppendLine("файл существует: " + File.Exists(path));
                sb.AppendLine("папка временных файлов: " + Path.GetTempPath() + " (запись: " + TempFolderWritable() + ")");

                if (File.Exists(path))
                {
                    try
                    {
                        using (var fs = File.Open(path, FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite))
                            sb.AppendLine("прямое открытие файла RW: OK (" + fs.Length + " байт)");
                    }
                    catch (Exception ex) { sb.AppendLine("прямое открытие файла RW: FAIL " + ex.GetType().Name + ": " + ex.Message); }

                    string lockFile = Path.Combine(Path.GetDirectoryName(path), Path.GetFileNameWithoutExtension(path) + ".laccdb");
                    sb.AppendLine("lock-файл (" + Path.GetFileName(lockFile) + "): " + (File.Exists(lockFile) ? "есть" : "нет"));
                }

                foreach (var candidate in Candidates(false))
                {
                    TryOpen(sb, candidate.Create, candidate.Label);
                }

                sb.AppendLine("токен: " + TokenInfo());
                sb.AppendLine("временный ключ ACE в реестре: " + VolatileKeyTest());
                sb.AppendLine("права на HKCU\\Software\\ODBC\\ODBC.INI: " + OdbcKeyAcl());
            }
            catch (Exception ex)
            {
                sb.AppendLine("диагностика не удалась: " + ex.Message);
            }

            return sb.ToString();
        }

        private static string IsElevated()
        {
            try
            {
                using (var identity = WindowsIdentity.GetCurrent())
                    return new WindowsPrincipal(identity).IsInRole(WindowsBuiltInRole.Administrator) ? "да" : "нет";
            }
            catch { return "неизвестно"; }
        }

        /// <summary>Можно ли писать в папку временных файлов, которой пользуется драйвер Access.</summary>
        private static string TempFolderWritable()
        {
            string folder = Path.GetTempPath();

            try
            {
                Directory.CreateDirectory(folder);
                string probe = Path.Combine(folder, "probe_" + Guid.NewGuid().ToString("N") + ".tmp");
                File.WriteAllText(probe, "ok");
                File.Delete(probe);
                return "OK";
            }
            catch (Exception ex)
            {
                return "FAIL " + ex.GetType().Name + ": " + ex.Message;
            }
        }

        /// <summary>Есть ли в токене процесса ограничения (restricted token / низкая целостность).</summary>
        private static string TokenInfo()
        {
            var sb = new StringBuilder(Environment.Is64BitProcess ? "64-bit" : "32-bit");

            try
            {
                using (var identity = WindowsIdentity.GetCurrent())
                {
                    foreach (IdentityReference group in identity.Groups)
                    {
                        string sid = group.Value;
                        if (sid == "S-1-5-12") sb.Append(", RESTRICTED");
                        else if (sid == "S-1-16-4096") sb.Append(", целостность низкая");
                        else if (sid == "S-1-16-8192") sb.Append(", целостность средняя");
                        else if (sid == "S-1-16-12288") sb.Append(", целостность высокая");
                        else if (sid == "S-1-16-16384") sb.Append(", целостность системная");
                    }

                    sb.Append(", SID=" + identity.User.Value);
                }
            }
            catch (Exception ex) { sb.Append(", ошибка чтения токена: " + ex.Message); }

            return sb.ToString();
        }

        [System.Runtime.InteropServices.DllImport("advapi32.dll", CharSet = System.Runtime.InteropServices.CharSet.Unicode, SetLastError = true)]
        private static extern int RegCreateKeyEx(IntPtr hKey, string subKey, int reserved, string className,
            int options, int samDesired, IntPtr securityAttributes, out IntPtr result, out int disposition);

        [System.Runtime.InteropServices.DllImport("advapi32.dll")]
        private static extern int RegCloseKey(IntPtr hKey);

        /// <summary>
        /// Проверяет, может ли процесс создать volatile-раздел реестра — именно это делает ACE
        /// ("Temporary (volatile) Ace DSN"). Если нельзя — база не откроется никаким провайдером.
        /// </summary>
        private static string VolatileKeyTest()
        {
            IntPtr hKey = IntPtr.Zero;
            IntPtr HKEY_CURRENT_USER = unchecked((IntPtr)(int)0x80000001);
            const int REG_OPTION_VOLATILE = 1;
            const int KEY_ALL_ACCESS = 0xF003F;

            try
            {
                int rc = RegCreateKeyEx(HKEY_CURRENT_USER,
                    @"Software\ODBC\ODBC.INI\Temporary (volatile) Ace DSN for process " + System.Diagnostics.Process.GetCurrentProcess().Id,
                    0, null, REG_OPTION_VOLATILE, KEY_ALL_ACCESS, IntPtr.Zero, out hKey, out int disposition);

                if (rc == 0)
                    return "OK (создать можно)";

                return "FAIL Win32=" + rc + " (" + new System.ComponentModel.Win32Exception(rc).Message + ")";
            }
            catch (Exception ex)
            {
                return "FAIL " + ex.Message;
            }
            finally
            {
                if (hKey != IntPtr.Zero) RegCloseKey(hKey);
            }
        }

        /// <summary>Права на ключ, в который ACE пишет свой временный раздел.</summary>
        private static string OdbcKeyAcl()
        {
            try
            {
                using (var key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(
                    @"Software\ODBC\ODBC.INI",
                    Microsoft.Win32.RegistryKeyPermissionCheck.ReadSubTree,
                    System.Security.AccessControl.RegistryRights.ReadPermissions))
                {
                    if (key == null) return "ключа нет";

                    var security = key.GetAccessControl(System.Security.AccessControl.AccessControlSections.Access);
                    var sb = new StringBuilder();

                    foreach (System.Security.AccessControl.RegistryAccessRule rule
                        in security.GetAccessRules(true, true, typeof(System.Security.Principal.NTAccount)))
                    {
                        sb.Append(rule.IdentityReference.Value).Append('=')
                          .Append(rule.RegistryRights).Append('/')
                          .Append(rule.AccessControlType).Append("; ");
                    }

                    return sb.ToString();
                }
            }
            catch (Exception ex) { return "не удалось прочитать (" + ex.GetType().Name + ": " + ex.Message + ")"; }
        }

        private static void TryOpen(StringBuilder sb, Func<DbConnection> create, string label)
        {
            try
            {
                using (var conn = create())
                {
                    conn.Open();
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = "SELECT COUNT(*) FROM [Клиенты]";
                        object n = cmd.ExecuteScalar();
                        sb.AppendLine(label + ": OK, клиентов = " + n);
                    }
                }
            }
            catch (Exception ex)
            {
                sb.AppendLine(label + ": FAIL " + Describe(ex));
            }
        }

        /// <summary>Краткое описание ошибки провайдера (SQLSTATE/код), если он их отдаёт.</summary>
        public static string Describe(Exception ex)
        {
            if (ex == null) return "неизвестная ошибка";

            var sb = new StringBuilder(ex.Message);

            var ole = ex as OleDbException;
            if (ole != null)
            {
                for (int i = 0; i < ole.Errors.Count; i++)
                    sb.AppendFormat(" [{0}/{1}: {2}]", ole.Errors[i].SQLState, ole.Errors[i].NativeError, (ole.Errors[i].Message ?? "").Trim());
            }

            var odbc = ex as OdbcException;
            if (odbc != null)
            {
                for (int i = 0; i < odbc.Errors.Count; i++)
                    sb.AppendFormat(" [{0}/{1}: {2}]", odbc.Errors[i].SQLState, odbc.Errors[i].NativeError, (odbc.Errors[i].Message ?? "").Trim());
            }

            sb.AppendFormat(" (HRESULT 0x{0:X8})", ex.HResult);

            string text = sb.ToString();

            if (IsAceRegistryProblem(text))
            {
                text += Environment.NewLine +
                    "Драйвер Access не смог подготовить служебные данные для подключения: " +
                    "ему недоступны ключ реестра HKEY_CURRENT_USER\\Software\\ODBC\\ODBC.INI " +
                    "или папка временных файлов (" + Path.GetTempPath() + "). " +
                    "Проверьте права на них и запускайте программу в обычном сеансе рабочего стола.";
            }
            else if (IsReadOnlyProblem(text))
            {
                text += Environment.NewLine +
                    "База открыта только для чтения. Снимите атрибут «Только чтение» с файла фитнес.accdb, " +
                    "закройте Access и другие копии программы и повторите.";
            }

            return text;
        }

        /// <summary>Признак того, что запись невозможна из-за режима «только чтение».</summary>
        private static bool IsReadOnlyProblem(string text)
        {
            if (string.IsNullOrEmpty(text)) return false;

            return text.IndexOf("updateable query", StringComparison.OrdinalIgnoreCase) >= 0
                || text.IndexOf("только для чтения", StringComparison.OrdinalIgnoreCase) >= 0
                || text.IndexOf("read-only", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        /// <summary>Признак того, что ACE не смог создать свой временный раздел реестра.</summary>
        private static bool IsAceRegistryProblem(string text)
        {
            if (string.IsNullOrEmpty(text)) return false;

            return text.IndexOf("Temporary (volatile) Ace DSN", StringComparison.OrdinalIgnoreCase) >= 0
                || text.IndexOf("Неопознанная ошибка", StringComparison.OrdinalIgnoreCase) >= 0
                || text.IndexOf("Unrecognized error", StringComparison.OrdinalIgnoreCase) >= 0;
        }
    }
}
