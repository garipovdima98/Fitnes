using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;

namespace Фитнес
{
    public partial class Form1 : Form
    {
        private string currentUserRole = "Пользователь";
        private int? currentUserClientId = null;

        public Form1(string role, int? clientId = null)
        {
            InitializeComponent();
            currentUserRole = role;
            currentUserClientId = clientId;
            this.tabControl1.SelectedIndexChanged += (s, e) => UpdateButtonsState();
        }

        private bool IsClientAccount
        {
            get { return currentUserRole == "Пользователь"; }
        }

        private bool HasClientId
        {
            get { return currentUserClientId.HasValue && currentUserClientId.Value > 0; }
        }

        // ==== Запросы для отображения: вместо id_* подставляем ФИО (и номер карты) ====
        private const string SqlClients =
            "SELECT к.[id_клиента], к.[фамилия], к.[имя], к.[отчество], к.[телефон], " +
            "л.[номер карты] FROM [Клиенты] AS к " +
            "LEFT JOIN [Карта лояльности] AS л ON к.[id_карты] = л.[id_карты]";

        private const string SqlTrainers =
            "SELECT [id_тренера], [фамилия], [имя], [отчество], [специальность] FROM [Тренеры]";

        private const string SqlAdmins =
            "SELECT [id_администратор], [фамилия], [имя], [отчество] FROM [Администраторы]";

        private const string SqlLoyalty =
            "SELECT [id_карты], [номер карты], [баллов], [скидка] FROM [Карта лояльности]";

        private const string SqlSubscriptions =
            "SELECT а.[id_абонимента], " +
            "к.[фамилия] AS [Клиент_фамилия], к.[имя] AS [Клиент_имя], к.[отчество] AS [Клиент_отчество], " +
            "а.[тип_абонемента], а.[начало], а.[конец], а.[статус] " +
            "FROM [Абонементы] AS а LEFT JOIN [Клиенты] AS к ON а.[id_клинета] = к.[id_клиента]";

        private const string SqlWorkouts =
            "SELECT т.[id_тренировки], " +
            "тр.[фамилия] AS [Тренер_фамилия], тр.[имя] AS [Тренер_имя], тр.[отчество] AS [Тренер_отчество], " +
            "к.[фамилия] AS [Клиент_фамилия], к.[имя] AS [Клиент_имя], к.[отчество] AS [Клиент_отчество], " +
            "ад.[фамилия] AS [Админ_фамилия], ад.[имя] AS [Админ_имя], ад.[отчество] AS [Админ_отчество], " +
            "т.[дата], т.[время], т.[забронировано], т.[оплачено] " +
            "FROM (([Тренировки] AS т LEFT JOIN [Тренеры] AS тр ON т.[id_тренера] = тр.[id_тренера]) " +
            "LEFT JOIN [Клиенты] AS к ON т.[id_клиента] = к.[id_клиента]) " +
            "LEFT JOIN [Администраторы] AS ад ON т.[id_администратора] = ад.[id_администратор]";

        /// <summary>
        /// ФИО собирается в C#, а не в SQL: в базе встречаются лишние пробелы и пустое отчество,
        /// а «&amp;» в запросе даёт неаккуратные «Васильева  Ангелина».
        /// </summary>
        private static void PrepareDisplayNames(DataTable dt)
        {
            PersonName.AddNameColumn(dt, "Тренер", "Тренер_фамилия", "Тренер_имя", "Тренер_отчество", true, 1);
            PersonName.AddNameColumn(dt, "Клиент", "Клиент_фамилия", "Клиент_имя", "Клиент_отчество", true, 2);
            PersonName.AddNameColumn(dt, "Администратор", "Админ_фамилия", "Админ_имя", "Админ_отчество", true, 3);
        }

        /// <summary>Пересобирает ФИО после поиска (там таблицы заполняются напрямую).</summary>
        private void RefreshDisplayNames()
        {
            PrepareDisplayNames(dgvSubscriptions.DataSource as DataTable);
            PrepareDisplayNames(dgvWorkouts.DataSource as DataTable);
        }

        // Служебные (id) колонки остаются в таблице для удаления/редактирования, но не показываются
        private void HideServiceColumns()
        {
            HideColumn(dgvClients, "id_клиента");
            HideColumn(dgvTrainers, "id_тренера");
            HideColumn(dgvAdmins, "id_администратор");
            HideColumn(dgvLoyalty, "id_карты");
            HideColumn(dgvSubscriptions, "id_абонимента");
            HideColumn(dgvWorkouts, "id_тренировки");

            // Колонки-«запчасти» ФИО нужны только для сборки имени в PrepareDisplayNames.
            HideColumn(dgvSubscriptions, "Клиент_фамилия");
            HideColumn(dgvSubscriptions, "Клиент_имя");
            HideColumn(dgvSubscriptions, "Клиент_отчество");
            HideColumn(dgvWorkouts, "Тренер_фамилия");
            HideColumn(dgvWorkouts, "Тренер_имя");
            HideColumn(dgvWorkouts, "Тренер_отчество");
            HideColumn(dgvWorkouts, "Клиент_фамилия");
            HideColumn(dgvWorkouts, "Клиент_имя");
            HideColumn(dgvWorkouts, "Клиент_отчество");
            HideColumn(dgvWorkouts, "Админ_фамилия");
            HideColumn(dgvWorkouts, "Админ_имя");
            HideColumn(dgvWorkouts, "Админ_отчество");
        }

        private static void HideColumn(DataGridView dgv, string columnName)
        {
            if (dgv.Columns.Contains(columnName))
                dgv.Columns[columnName].Visible = false;
        }

        private void FormatGrids()
        {
            if (dgvWorkouts.Columns.Contains("время"))
                dgvWorkouts.Columns["время"].DefaultCellStyle.Format = "t";
            if (dgvWorkouts.Columns.Contains("дата"))
                dgvWorkouts.Columns["дата"].DefaultCellStyle.Format = "dd.MM.yyyy";
            if (dgvWorkouts.Columns.Contains("Тренер"))
                dgvWorkouts.Columns["Тренер"].HeaderText = "Тренер";
            if (dgvWorkouts.Columns.Contains("Клиент"))
                dgvWorkouts.Columns["Клиент"].HeaderText = "Клиент";
            if (dgvWorkouts.Columns.Contains("Администратор"))
                dgvWorkouts.Columns["Администратор"].HeaderText = "Администратор";

            if (dgvSubscriptions.Columns.Contains("начало"))
                dgvSubscriptions.Columns["начало"].DefaultCellStyle.Format = "dd.MM.yyyy";
            if (dgvSubscriptions.Columns.Contains("конец"))
                dgvSubscriptions.Columns["конец"].DefaultCellStyle.Format = "dd.MM.yyyy";
            if (dgvSubscriptions.Columns.Contains("Клиент"))
                dgvSubscriptions.Columns["Клиент"].HeaderText = "Клиент";

            if (dgvClients.Columns.Contains("номер карты"))
                dgvClients.Columns["номер карты"].HeaderText = "Карта лояльности";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SubscriptionsHelper.ОбновитьСтатусы();
            LoadAllData();
            ApplyAccessRights();

            if (IsClientAccount && !HasClientId)
            {
                MessageBox.Show(
                    "Учётная запись не привязана к клиенту, поэтому личные данные не отображаются.\n" +
                    "Обратитесь к администратору клуба.",
                    "Ограничение доступа", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void ApplyAccessRights()
        {
            this.Text = $"Фитнес-клуб — Панель управления ({currentUserRole})";

            if (!IsClientAccount) return;

            for (int i = tabControl1.TabPages.Count - 1; i >= 0; i--)
            {
                string tabText = tabControl1.TabPages[i].Text.Trim();
                if (tabText != "Тренировки" && tabText != "Администраторы" &&
                    tabText != "Тренеры" && tabText != "Абонементы")
                {
                    tabControl1.TabPages.RemoveAt(i);
                }
            }

            UpdateButtonsState();
        }

        private void UpdateButtonsState()
        {
            if (!IsClientAccount) return;

            btnDelete.Enabled = false;
            btnDelete.BackColor = System.Drawing.Color.Gray;

            string currentTab = SelectedTabText();
            bool canAdd = (currentTab == "Тренировки" || currentTab == "Абонементы");

            btnAdd.Enabled = canAdd;
            btnAdd.BackColor = canAdd ? System.Drawing.Color.Green : System.Drawing.Color.Gray;
        }

        private string SelectedTabText()
        {
            TabPage page = tabControl1.SelectedTab;
            return page == null ? string.Empty : page.Text.Trim();
        }

        public void LoadAllData()
        {
            var failed = new List<string>();

            // До трёх проходов: база может быть кратковременно занята (антивирус, вторая копия, отладчик)
            for (int pass = 1; pass <= 3; pass++)
            {
                failed = new List<string>();
                LoadAllGrids(failed);

                if (failed.Count == 0) break;
                if (pass < 3) System.Threading.Thread.Sleep(2000);
            }

            HideServiceColumns();
            FormatGrids();

            if (failed.Count > 0)
            {
                AppLog.Write("диагностика базы", DbHelper.Diagnose());
                ShowLoadError(string.Join(Environment.NewLine, failed));
            }
        }

        private void LoadAllGrids(List<string> failed)
        {
            // Каждая таблица грузится отдельно: сбой одной не ломает остальные
            LoadGrid(dgvClients, "Клиенты", SqlClients, failed);
            LoadGrid(dgvTrainers, "Тренеры", SqlTrainers, failed);
            LoadGrid(dgvAdmins, "Администраторы", SqlAdmins, failed);
            LoadGrid(dgvLoyalty, "Карты лояльности", SqlLoyalty, failed);

            if (IsClientAccount)
            {
                if (HasClientId)
                {
                    // Показываем только записи текущего клиента, но с ФИО вместо id
                    LoadGrid(dgvSubscriptions, "Абонементы",
                        SqlSubscriptions + " WHERE а.[id_клинета] = ?", failed, currentUserClientId.Value);
                    LoadGrid(dgvWorkouts, "Тренировки",
                        SqlWorkouts + " WHERE т.[id_клиента] = ?", failed, currentUserClientId.Value);
                }
                else
                {
                    // Нет привязки к клиенту — показывать чужие абонементы и тренировки нельзя.
                    dgvSubscriptions.DataSource = null;
                    dgvWorkouts.DataSource = null;
                }
            }
            else
            {
                LoadGrid(dgvSubscriptions, "Абонементы", SqlSubscriptions, failed);
                LoadGrid(dgvWorkouts, "Тренировки", SqlWorkouts, failed);
            }
        }

        private void LoadGrid(DataGridView grid, string title, string sql, List<string> failed, params object[] parameters)
        {
            Exception last = null;

            // До 2 попыток на таблицу: если база недоступна, весь набор повторится в LoadAllData
            for (int attempt = 1; attempt <= 2; attempt++)
            {
                try
                {
                    DataTable dt = DbHelper.Query(sql, parameters);
                    PrepareDisplayNames(dt);
                    grid.DataSource = dt;
                    return;
                }
                catch (Exception ex)
                {
                    last = ex;
                    System.Threading.Thread.Sleep(200 * (1 << (attempt - 1))); // 200/400 мс
                }
            }

            LogError(title, sql, last);
            failed.Add("• " + title + " — " + DescribeError(last));
        }

        private void ShowLoadError(string details)
        {
            MessageBox.Show(
                "Не удалось загрузить часть данных:" + Environment.NewLine + Environment.NewLine +
                details + Environment.NewLine + Environment.NewLine +
                "Частые причины:" + Environment.NewLine +
                "  • база фитнес.accdb открыта в Access или запущена вторая копия программы;" + Environment.NewLine +
                "  • файл базы ещё синхронизируется (OneDrive) или повреждён;" + Environment.NewLine +
                "  • не установлен драйвер Microsoft Access Database Engine." + Environment.NewLine + Environment.NewLine +
                "Закройте лишние программы/копии и нажмите «Найти» с пустым полем, чтобы перезагрузить данные." + Environment.NewLine +
                "Подробности записаны в error.log рядом с exe.",
                "Ошибка БД", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private static string DescribeError(Exception ex)
        {
            return DbHelper.Describe(ex);
        }

        private static void LogError(string title, string sql, Exception ex)
        {
            string details =
                "SQL: " + sql + Environment.NewLine +
                "Описание: " + DbHelper.Describe(ex) + Environment.NewLine +
                "DataDirectory: " + Convert.ToString(AppDomain.CurrentDomain.GetData("DataDirectory")) +
                Environment.NewLine + ex;

            AppLog.Write("ошибка загрузки: " + title, details);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string currentTab = SelectedTabText();

            if (IsClientAccount && currentTab != "Тренировки" && currentTab != "Абонементы")
            {
                MessageBox.Show("У вас нет прав для добавления в этот раздел.", "Отказано",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            switch (currentTab)
            {
                case "Клиенты":
                    new FormAddClient().ShowDialog();
                    break;
                case "Тренеры":
                    new FormAddTrainer().ShowDialog();
                    break;
                case "Администраторы":
                    new FormAddAdmin().ShowDialog();
                    break;
                case "Абонементы":
                    if (IsClientAccount && HasClientId)
                    {
                        new FormAddSub(currentUserClientId.Value).ShowDialog();
                    }
                    else
                    {
                        new FormAddSub().ShowDialog();
                    }
                    break;
                case "Тренировки":
                    if (IsClientAccount && HasClientId)
                    {
                        new FormAddWorkout(currentUserClientId.Value).ShowDialog();
                    }
                    else
                    {
                        new FormAddWorkout().ShowDialog();
                    }
                    break;
            }
            LoadAllData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (currentUserRole != "Администратор")
            {
                MessageBox.Show("Удалять записи может только администратор.", "Отказано",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridView dgv = null;
            string table = "", pk = "";

            switch (SelectedTabText())
            {
                case "Клиенты": dgv = dgvClients; table = "Клиенты"; pk = "id_клиента"; break;
                case "Тренеры": dgv = dgvTrainers; table = "Тренеры"; pk = "id_тренера"; break;
                case "Администраторы": dgv = dgvAdmins; table = "Администраторы"; pk = "id_администратор"; break;
                case "Абонементы": dgv = dgvSubscriptions; table = "Абонементы"; pk = "id_абонимента"; break;
                case "Тренировки": dgv = dgvWorkouts; table = "Тренировки"; pk = "id_тренировки"; break;
                case "Карты лояльности": dgv = dgvLoyalty; table = "Карта лояльности"; pk = "id_карты"; break;
                default: return;
            }

            if (dgv.CurrentRow == null)
            {
                MessageBox.Show("Выберите строку.", "Удаление", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButtons.YesNo) != DialogResult.Yes)
                return;

            try
            {
                int id = Convert.ToInt32(dgv.CurrentRow.Cells[pk].Value);

                // Связанные записи (абонементы, тренировки, клиенты карты) удаляются каскадом —
                // это настроено в самой базе фитнес.accdb.
                DbHelper.Execute($"DELETE FROM [{table}] WHERE [{pk}] = ?", id);
                LoadAllData();
            }
            catch (Exception ex)
            {
                AppLog.WriteException("удаление из " + table, ex);
                MessageBox.Show("Ошибка удаления: " + DbHelper.Describe(ex), "Ошибка БД",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            string q = txtSearch.Text.Trim();
            if (string.IsNullOrEmpty(q)) { LoadAllData(); return; }

            try
            {
                string like = "%" + q + "%";
                bool ownOnly = IsClientAccount && HasClientId;

                switch (SelectedTabText())
                {
                    case "Клиенты":
                        dgvClients.DataSource = DbHelper.Query(
                            SqlClients + " WHERE к.[фамилия] LIKE ? OR к.[имя] LIKE ? OR к.[отчество] LIKE ? " +
                            "OR к.[телефон] LIKE ? OR л.[номер карты] LIKE ?",
                            like, like, like, like, like);
                        break;
                    case "Тренеры":
                        dgvTrainers.DataSource = DbHelper.Query(
                            SqlTrainers + " WHERE [фамилия] LIKE ? OR [специальность] LIKE ?", like, like);
                        break;
                    case "Администраторы":
                        dgvAdmins.DataSource = DbHelper.Query(
                            SqlAdmins + " WHERE [фамилия] LIKE ?", like);
                        break;
                    case "Абонементы":
                        if (IsClientAccount && !HasClientId)
                        {
                            dgvSubscriptions.DataSource = null;
                        }
                        else if (ownOnly)
                        {
                            dgvSubscriptions.DataSource = DbHelper.Query(
                                SqlSubscriptions + " WHERE (к.[фамилия] LIKE ? OR к.[имя] LIKE ? " +
                                "OR а.[тип_абонемента] LIKE ? OR а.[статус] LIKE ?) AND а.[id_клинета] = ?",
                                like, like, like, like, currentUserClientId.Value);
                        }
                        else
                        {
                            dgvSubscriptions.DataSource = DbHelper.Query(
                                SqlSubscriptions + " WHERE к.[фамилия] LIKE ? OR к.[имя] LIKE ? " +
                                "OR а.[тип_абонемента] LIKE ? OR а.[статус] LIKE ?",
                                like, like, like, like);
                        }
                        break;
                    case "Тренировки":
                        if (IsClientAccount && !HasClientId)
                        {
                            dgvWorkouts.DataSource = null;
                        }
                        else if (ownOnly)
                        {
                            dgvWorkouts.DataSource = DbHelper.Query(
                                SqlWorkouts + " WHERE (тр.[фамилия] LIKE ? OR к.[фамилия] LIKE ? " +
                                "OR к.[имя] LIKE ? OR CStr(т.[дата]) LIKE ?) AND т.[id_клиента] = ?",
                                like, like, like, like, currentUserClientId.Value);
                        }
                        else
                        {
                            dgvWorkouts.DataSource = DbHelper.Query(
                                SqlWorkouts + " WHERE тр.[фамилия] LIKE ? OR тр.[имя] LIKE ? " +
                                "OR к.[фамилия] LIKE ? OR к.[имя] LIKE ? OR ад.[фамилия] LIKE ? " +
                                "OR CStr(т.[дата]) LIKE ?",
                                like, like, like, like, like, like);
                        }
                        break;
                    case "Карты лояльности":
                        dgvLoyalty.DataSource = DbHelper.Query(
                            SqlLoyalty + " WHERE [номер карты] LIKE ?", like);
                        break;
                }

                RefreshDisplayNames();
                HideServiceColumns();
                FormatGrids();
            }
            catch (Exception ex)
            {
                LogError("Поиск", txtSearch.Text, ex);
                MessageBox.Show("Ошибка поиска: " + DescribeError(ex) + Environment.NewLine +
                                "Подробности записаны в error.log рядом с exe.", "Ошибка БД",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvLoyalty_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            if (currentUserRole != "Администратор")
            {
                MessageBox.Show("У вас нет прав для изменения карт лояльности.", "Отказано",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!dgvLoyalty.Columns.Contains("id_карты")) return;
            if (e.RowIndex >= dgvLoyalty.Rows.Count) return;

            object value = dgvLoyalty.Rows[e.RowIndex].Cells["id_карты"].Value;
            if (value == null || value == DBNull.Value) return;

            int cardId = Convert.ToInt32(value);
            new FormEditLoyalty(cardId).ShowDialog();
            LoadAllData();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
