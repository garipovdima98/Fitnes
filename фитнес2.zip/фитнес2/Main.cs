using System;
using System.IO;
using System.Windows.Forms;

namespace Фитнес
{
    public partial class Main : Form
    {
        public bool IsAuthenticated { get; private set; } = false;
        public string UserRole { get; private set; } = "Пользователь";
        public int? UserClientId { get; private set; } = null;

        public Main()
        {
            InitializeComponent();
            txtPassword.UseSystemPasswordChar = true;
        }

        private void button2_Click(object sender, EventArgs e) => Application.Exit();

        private void button1_Click(object sender, EventArgs e)
        {
            string login = txtlogin.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Введите логин и пароль!");
                return;
            }

            if (string.Equals(login, "admin", StringComparison.OrdinalIgnoreCase) && password == "admin")
            {
                UserRole = "Администратор";
                UserClientId = null;
                IsAuthenticated = true;
                MessageBox.Show("Вход выполнен. Права: Администратор");
                this.Close();
                return;
            }

            if (!File.Exists(AppPaths.SystemConfig))
            {
                MessageBox.Show("Учётная запись не найдена.\nЗарегистрируйтесь: кнопка «Регистрация».");
                return;
            }

            int? clientId;
            if (!AppPaths.TryFindUser(login, password, out clientId))
            {
                MessageBox.Show("Неверный логин или пароль.");
                return;
            }

            // Учётная запись без привязки к клиенту бесполезна: непонятно, чьи данные показывать.
            if (!clientId.HasValue || clientId.Value <= 0)
            {
                MessageBox.Show(
                    "Учётная запись не привязана к клиенту.\n" +
                    "Зарегистрируйтесь заново или обратитесь к администратору клуба.");
                return;
            }

            UserRole = "Пользователь";
            UserClientId = clientId;
            IsAuthenticated = true;
            MessageBox.Show($"Вход выполнен.");
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new FormAuth().ShowDialog();
        }
    }
}
