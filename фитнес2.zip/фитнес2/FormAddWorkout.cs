using System;
using System.Data;
using System.Windows.Forms;

namespace Фитнес
{
    public partial class FormAddWorkout : Form
    {
        /// <summary>Дата, которую Access хранит у «чистого» времени (как в старых записях).</summary>
        private static readonly DateTime TimeOnlyBase = new DateTime(1899, 12, 30);

        private int? lockedClientId = null;

        public FormAddWorkout()
        {
            InitializeComponent();
            dtpDate.Value = DateTime.Today;
            dtpTime.Value = DateTime.Now;

            // Колесо мыши меняет время; SendKeys требует активного окна, поэтому на всякий случай ловим ошибку.
            this.dtpTime.MouseWheel += (s, e) =>
            {
                try { SendKeys.Send(e.Delta > 0 ? "{UP}" : "{DOWN}"); }
                catch (InvalidOperationException) { }
            };
        }

        public FormAddWorkout(int clientId) : this() { lockedClientId = clientId; }

        private void FormAddWorkout_Load(object sender, EventArgs e)
        {
            try
            {
                LoadComboTrainers();
                LoadComboClients();
                LoadComboAdmins();
            }
            catch (Exception ex)
            {
                AppLog.WriteException("списки для тренировки", ex);
                MessageBox.Show(
                    "Не удалось загрузить списки тренеров/клиентов/администраторов: " + DbHelper.Describe(ex),
                    "Ошибка БД", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnSave.Enabled = false;
                return;
            }

            if (lockedClientId.HasValue)
            {
                bool found = SelectClient(lockedClientId.Value);
                cmbClient.Enabled = false;
                cmbClient.BackColor = System.Drawing.Color.LightGray;

                if (!found)
                {
                    MessageBox.Show(
                        "Клиент, к которому привязана учётная запись, не найден в базе.\n" +
                        "Запись на тренировку недоступна.",
                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    btnSave.Enabled = false;
                }
            }
        }

        private bool SelectClient(int clientId)
        {
            for (int i = 0; i < cmbClient.Items.Count; i++)
            {
                DataRowView row = cmbClient.Items[i] as DataRowView;
                if (row != null && Convert.ToInt32(row["id_клиента"]) == clientId)
                {
                    cmbClient.SelectedIndex = i;
                    return true;
                }
            }

            return false;
        }

        private void LoadComboTrainers()
        {
            var dt = DbHelper.Query(
                "SELECT id_тренера, фамилия, имя, отчество FROM [Тренеры] ORDER BY фамилия, имя");
            PersonName.AddFullNameColumn(dt, "ФИО", "фамилия", "имя", "отчество");
            cmbTrainer.DataSource = dt;
            cmbTrainer.DisplayMember = "ФИО";
            cmbTrainer.ValueMember = "id_тренера";
        }

        private void LoadComboClients()
        {
            var dt = DbHelper.Query(
                "SELECT id_клиента, фамилия, имя, отчество FROM [Клиенты] ORDER BY фамилия, имя");
            PersonName.AddFullNameColumn(dt, "ФИО", "фамилия", "имя", "отчество");
            cmbClient.DataSource = dt;
            cmbClient.DisplayMember = "ФИО";
            cmbClient.ValueMember = "id_клиента";
        }

        private void LoadComboAdmins()
        {
            var dt = DbHelper.Query(
                "SELECT id_администратор, фамилия, имя, отчество FROM [Администраторы] ORDER BY фамилия, имя");
            PersonName.AddFullNameColumn(dt, "ФИО", "фамилия", "имя", "отчество");
            cmbAdmin.DataSource = dt;
            cmbAdmin.DisplayMember = "ФИО";
            cmbAdmin.ValueMember = "id_администратор";
        }

        /// <summary>
        /// Проверяет интервал 1 час 30 минут у выбранного тренера на выбранную дату.
        /// Сравниваются только часы и минуты, поэтому базовая дата у обеих величин одна.
        /// </summary>
        private bool IsTimeSlotBusy(DateTime date, TimeSpan time, int trainerId)
        {
            DateTime newWorkoutDateTime = TimeOnlyBase.Add(time);

            // Строго на указанную дату: DateValue отсекает время в поле [дата].
            string sql = "SELECT [время] FROM [Тренировки] WHERE [id_тренера] = ? AND DateValue([дата]) = DateValue(?)";
            DataTable dt = DbHelper.Query(sql, trainerId, date.Date);

            foreach (DataRow row in dt.Rows)
            {
                if (row["время"] == DBNull.Value) continue;

                TimeSpan dbTime;

                // Access может вернуть время как TimeSpan или как DateTime.
                if (row["время"] is TimeSpan)
                {
                    dbTime = (TimeSpan)row["время"];
                }
                else
                {
                    dbTime = Convert.ToDateTime(row["время"]).TimeOfDay;
                }

                DateTime existingWorkoutDateTime = TimeOnlyBase.Add(dbTime);
                double minutesDifference = Math.Abs((newWorkoutDateTime - existingWorkoutDateTime).TotalMinutes);

                if (minutesDifference < 90)
                {
                    return true; // Слот действительно занят
                }
            }

            return false; // Слот свободен
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cmbTrainer.SelectedValue == null) { MessageBox.Show("Выберите тренера."); return; }
            if (cmbAdmin.SelectedValue == null) { MessageBox.Show("Выберите администратора."); return; }

            int idClient;
            if (lockedClientId.HasValue && lockedClientId.Value > 0)
                idClient = lockedClientId.Value;
            else
            {
                if (cmbClient.SelectedValue == null) { MessageBox.Show("Выберите клиента."); return; }
                idClient = Convert.ToInt32(cmbClient.SelectedValue);
            }

            if (idClient <= 0)
            {
                MessageBox.Show("Неверный ID клиента. Перерегистрируйтесь (удалите system_config.dat).");
                return;
            }

            int idTrainer = Convert.ToInt32(cmbTrainer.SelectedValue);
            int idAdmin = Convert.ToInt32(cmbAdmin.SelectedValue);

            DateTime selectedDate = dtpDate.Value.Date;

            // Секунды не нужны: в базе время хранится с точностью до минуты.
            TimeSpan selectedTime = new TimeSpan(dtpTime.Value.Hour, dtpTime.Value.Minute, 0);

            try
            {
                if (DbHelper.Count("SELECT COUNT(*) FROM [Клиенты] WHERE [id_клиента] = ?", idClient) == 0)
                {
                    MessageBox.Show($"Клиент с ID {idClient} не найден в базе.");
                    return;
                }

                if (IsTimeSlotBusy(selectedDate, selectedTime, idTrainer))
                {
                    MessageBox.Show(
                        "Этот временной слот занят! Запись к выбранному тренеру возможна только с интервалом не менее 1 часа 30 минут от других его тренировок.",
                        "Внимание",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                    return;
                }

                DbHelper.Execute(
                    "INSERT INTO [Тренировки] ([id_тренера],[id_клиента],[id_администратора],[дата],[время],[забронировано],[оплачено]) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    idTrainer, idClient, idAdmin, selectedDate, TimeOnlyBase.Add(selectedTime),
                    chkBooked.Checked, chkPaid.Checked);

                MessageBox.Show("Тренировка добавлена!");
                this.Close();
            }
            catch (Exception ex)
            {
                AppLog.WriteException("добавление тренировки", ex);
                MessageBox.Show(
                    "Не удалось добавить тренировку: " + DbHelper.Describe(ex) + Environment.NewLine +
                    "Подробности записаны в error.log рядом с exe.",
                    "Ошибка БД", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e) => this.Close();
    }
}
