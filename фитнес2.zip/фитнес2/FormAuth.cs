using System;
using System.Windows.Forms;

namespace Фитнес
{
    /// <summary>
    /// Регистрация клиента: создаёт (или находит) клиента в базе и добавляет
    /// учётную запись в system_config.dat.
    /// </summary>
    public partial class FormAuth : Form
    {
        public FormAuth()
        {
            InitializeComponent();
            txtPassword.UseSystemPasswordChar = true;
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Text.Trim();
            string lastName = txtLastName.Text.Trim();
            string firstName = txtFirstName.Text.Trim();
            string middleName = txtMiddleName.Text.Trim();
            string phone = PhoneHelper.Normalize(txtPhone.Text);

            if (login.Length == 0 || password.Length == 0 || lastName.Length == 0 || firstName.Length == 0)
            {
                MessageBox.Show("Заполните обязательные поля: логин, пароль, фамилию и имя.");
                return;
            }

            if (string.IsNullOrEmpty(phone))
            {
                MessageBox.Show("Телефон должен содержать 10 или 11 цифр, например +7 999 123-45-67.");
                return;
            }

            if (string.Equals(login, "admin", StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.Show("Логин «admin» зарезервирован.");
                return;
            }

            if (login.IndexOf('|') >= 0 || password.IndexOf('|') >= 0)
            {
                MessageBox.Show("Символ «|» в логине и пароле недопустим.");
                return;
            }

            // Логин проверяем ДО создания клиента и карты, иначе при занятом логине
            // в базе остаётся «мусорная» запись.
            if (AppPaths.IsLoginTaken(login))
            {
                MessageBox.Show("Логин занят.");
                return;
            }

            try
            {
                int clientId = FindOrCreateClient(lastName, firstName, middleName, phone);
                AppPaths.AppendUser(login, password, clientId);

                MessageBox.Show($"Регистрация успешна!");
                this.Close();
            }
            catch (Exception ex)
            {
                AppLog.WriteException("регистрация клиента", ex);
                MessageBox.Show(
                    "Ошибка регистрации: " + DbHelper.Describe(ex) + Environment.NewLine +
                    "Подробности записаны в error.log рядом с exe.",
                    "Ошибка БД", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>Клиент с таким телефоном уже есть — используем его, иначе создаём нового.</summary>
        private static int FindOrCreateClient(string lastName, string firstName, string middleName, string phone)
        {
            int existing = DbHelper.ScalarInt("SELECT id_клиента FROM [Клиенты] WHERE [телефон] = ?", phone);
            if (existing > 0) return existing;

            int cardId = LoyaltyHelper.CreateCard();

            DbHelper.Execute(
                "INSERT INTO [Клиенты] ([фамилия],[имя],[отчество],[телефон],[id_карты]) VALUES (?, ?, ?, ?, ?)",
                lastName, firstName, middleName, phone, cardId);

            int clientId = DbHelper.ScalarInt("SELECT MAX(id_клиента) FROM [Клиенты]");
            if (clientId <= 0)
                throw new InvalidOperationException("Клиент добавлен, но его id определить не удалось.");

            return clientId;
        }

        // «Отмена» закрывает только это окно, а не всю программу.
        private void btnCancel_Click(object sender, EventArgs e) => this.Close();
    }
}
