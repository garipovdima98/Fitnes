using System;
using System.Windows.Forms;

namespace Фитнес
{
    public partial class FormAddAdmin : Form
    {
        public FormAddAdmin()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string lastName = txtLast.Text.Trim();
            string firstName = txtFirst.Text.Trim();
            string middleName = txtMiddle.Text.Trim();

            if (lastName.Length == 0)
            {
                MessageBox.Show("Введите фамилию.");
                return;
            }

            try
            {
                if (DbHelper.Count(
                        "SELECT COUNT(*) FROM [Администраторы] WHERE [фамилия]=? AND [имя]=? AND [отчество]=?",
                        lastName, firstName, middleName) > 0)
                {
                    MessageBox.Show("Такой администратор уже есть.");
                    return;
                }

                DbHelper.Execute(
                    "INSERT INTO [Администраторы] ([фамилия],[имя],[отчество]) VALUES (?, ?, ?)",
                    lastName, firstName, middleName);

                MessageBox.Show("Администратор добавлен!");
                this.Close();
            }
            catch (Exception ex)
            {
                AppLog.WriteException("добавление администратора", ex);
                MessageBox.Show(
                    "Не удалось добавить администратора: " + DbHelper.Describe(ex) + Environment.NewLine +
                    "Подробности записаны в error.log рядом с exe.",
                    "Ошибка БД", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e) => this.Close();
    }
}
