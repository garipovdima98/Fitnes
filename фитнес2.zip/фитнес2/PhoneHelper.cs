﻿using System.Text.RegularExpressions;

namespace Фитнес
{
    public static class PhoneHelper
    {
        public static string Normalize(string phone)
        {
            if (string.IsNullOrWhiteSpace(phone)) return string.Empty;
            string digits = Regex.Replace(phone, @"\D", "");
            if (digits.Length == 11 && (digits[0] == '8' || digits[0] == '7'))
                return "+7" + digits.Substring(1);
            if (digits.Length == 10)
                return "+7" + digits;
            return string.Empty;
        }
    }
}